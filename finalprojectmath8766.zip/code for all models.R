setwd("C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project")
setwd("C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project")
library(Amelia)
library(car)
library(gbm)
library(MASS)
library(randomForest)
library(glmnet)




############load data and put in correct format##############

train=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=train[,-1]



sample.list=sample(nrow(train), nrow(train)/10)

train.set=train[-sample.list,]
valid.set=train[sample.list,]
amelia.set=amelia(train.set)

amelia.set1=amelia.set$imputations$imp1
amelia.set1$NumberOfDependents=round(amelia.set1$NumberOfDependents)
amelia.set1$MonthlyIncome=round(amelia.set1$MonthlyIncome)
amelia.set1=abs(amelia.set1)
amelia.set1$SeriousDlqin2yrs=as.factor(amelia.set1$SeriousDlqin2yrs)

amelia.valid=amelia(valid.set)
amelia.valid1=amelia.valid$imputations$imp1
amelia.valid1$NumberOfDependents=round(amelia.valid1$NumberOfDependents)
amelia.valid1$MonthlyIncome=round(amelia.valid1$MonthlyIncome)
amelia.valid1=abs(amelia.valid1)
amelia.valid1$SeriousDlqin2yrs=as.factor(amelia.valid1$SeriousDlqin2yrs)



############ test whether or amelia is any good, only need to test cols 11 and 6
############ because there are no na's in any other columns
par(mfrow=c(1,2))
list.nas.11=which(is.na(valid.set[,11]))
hist(valid.set[,11])
hist(amelia.valid1[list.nas.11,11], xlim = c(0,8))

list.nas.6=which(is.na(valid.set[,6]))
hist(valid.set[,6], xlim = c(0,50000), breaks = 1000)
hist(amelia.valid1[list.nas.6,6], xlim = c(0,50000), breaks = 100)


############ fit a model###############
amelia.glm.full=glm(SeriousDlqin2yrs~ (.+.)^4, data=amelia.set1, family="binomial")
amelia.glm.null=glm(SeriousDlqin2yrs~+1, data=amelia.set1,family="binomial")


###used this to get the model###

#step(amelia.glm.null, direction="both", scope=list(lower=amelia.glm.null, upper=amelia.glm.full),
#     scale=0)

####################

amelia.glm=glm(formula = SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 NumberRealEstateLoansOrLines + MonthlyIncome + NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 MonthlyIncome:NumberOfDependents + age:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberRealEstateLoansOrLines + 
                 age:NumberOfDependents + age:NumberOfTime30.59DaysPastDueNotWorse + 
                 age:NumberRealEstateLoansOrLines + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:MonthlyIncome:NumberOfDependents + age:NumberOfTime30.59DaysPastDueNotWorse:NumberRealEstateLoansOrLines, 
               family = "binomial", data = amelia.set1)
summary(amelia.glm)



#################### make some predictions ##############
pred=round(predict(amelia.glm, newdata= amelia.valid1[,-1], type="response"))
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)


#################### make some predictions for submission ##############
test=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)
test=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)


amelia.test=amelia(test[,-(1:2)])
amelia.test1=amelia.test$imputations$imp1
amelia.test1$NumberOfDependents=round(amelia.test1$NumberOfDependents)
amelia.test1$MonthlyIncome=round(amelia.test1$MonthlyIncome)
amelia.test1=abs(amelia.test1)


pred=predict(amelia.glm, newdata= amelia.test1, type="response")
pred=as.data.frame(pred)
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"glm_submission4 quad interactions.csv",row.names = FALSE)



##################################################################
#amelia.gbm=gbm(SeriousDlqin2yrs~.*., data=amelia.set1, n.trees=5000, distribution = "bernoulli")
amelia.gbm2=gbm(SeriousDlqin2yrs~NumberOfTimes90DaysLate+RevolvingUtilizationOfUnsecuredLines+
                  NumberOfTime30.59DaysPastDueNotWorse+
                  NumberOfTime60.89DaysPastDueNotWorse+
                  age+NumberRealEstateLoansOrLines, n.trees=5000,
                distribution="bernoulli",data=amelia.set1,interaction.depth = 10)


summary(amelia.gbm2)


#################### make some predictions ##############
pred=predict(amelia.gbm2, newdata= amelia.valid1[,-1],type = "response", n.trees=5000)
pred=round(pred)
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)



###############################################################
@
  
  <<>>=

############load data and put in correct format##############

train=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=train[,-1]

for(i in 1:nrow(train)){
  if (train[i,2] > 1){
    train[i,2]= 1
  }}

train[,2]=logit(train[,2]^.5)
for(i in 1:nrow(train)){
  if (train[i,4]>13){
    train[i,4]=13
  }
}


sample.list=sample(nrow(train), nrow(train)/10)

train.set=train[-sample.list,]
valid.set=train[sample.list,]
amelia.set=amelia(train.set)

amelia.set1=amelia.set$imputations$imp1
amelia.set1$NumberOfDependents=round(amelia.set1$NumberOfDependents)
amelia.set1$MonthlyIncome=round(amelia.set1$MonthlyIncome)
amelia.set1=abs(amelia.set1)
amelia.set1$SeriousDlqin2yrs=as.factor(amelia.set1$SeriousDlqin2yrs)


############ fit a model###############
amelia.glm.full=glm(SeriousDlqin2yrs~ (.+.)^3, data=amelia.set1, family="binomial")
amelia.glm.null=glm(SeriousDlqin2yrs~+1, data=amelia.set1,family="binomial")


###used this to get the model###

step(amelia.glm, direction="both", scope=list(lower=amelia.glm, upper=amelia.glm.full),
     scale=0)

####################

amelia.glm=glm(formula = SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + RevolvingUtilizationOfUnsecuredLines + 
                 DebtRatio + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans + NumberOfTimes90DaysLate:RevolvingUtilizationOfUnsecuredLines + 
                 NumberOfTime60.89DaysPastDueNotWorse:RevolvingUtilizationOfUnsecuredLines + 
                 NumberOfTime30.59DaysPastDueNotWorse:RevolvingUtilizationOfUnsecuredLines + 
                 NumberRealEstateLoansOrLines:RevolvingUtilizationOfUnsecuredLines + 
                 age:NumberRealEstateLoansOrLines + NumberOfTime30.59DaysPastDueNotWorse:DebtRatio + 
                 age:DebtRatio + RevolvingUtilizationOfUnsecuredLines:DebtRatio + 
                 NumberOfTime60.89DaysPastDueNotWorse:DebtRatio + NumberOfOpenCreditLinesAndLoans:DebtRatio + 
                 NumberOfTime60.89DaysPastDueNotWorse:MonthlyIncome + NumberOfTimes90DaysLate:MonthlyIncome + 
                 age:RevolvingUtilizationOfUnsecuredLines + MonthlyIncome:RevolvingUtilizationOfUnsecuredLines + 
                 NumberOfTimes90DaysLate:NumberRealEstateLoansOrLines + NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate:RevolvingUtilizationOfUnsecuredLines + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse:RevolvingUtilizationOfUnsecuredLines + 
                 age:NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate:RevolvingUtilizationOfUnsecuredLines + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:RevolvingUtilizationOfUnsecuredLines:DebtRatio + 
                 age:RevolvingUtilizationOfUnsecuredLines:DebtRatio + age:NumberOfTime60.89DaysPastDueNotWorse:RevolvingUtilizationOfUnsecuredLines + 
                 age:NumberOfTime60.89DaysPastDueNotWorse:DebtRatio + NumberOfTimes90DaysLate:NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans, 
               family = "binomial", data = amelia.set1)
summary(amelia.glm)

############ put valid set data in right format
amelia.valid=amelia(valid.set)
amelia.valid1=amelia.valid$imputations$imp1
amelia.valid1$NumberOfDependents=round(amelia.valid1$NumberOfDependents)
amelia.valid1$MonthlyIncome=round(amelia.valid1$MonthlyIncome)
amelia.valid1=abs(amelia.valid1)
amelia.valid1$SeriousDlqin2yrs=as.factor(amelia.valid1$SeriousDlqin2yrs)


#################### make some predictions ##############
pred=round(predict(amelia.glm, newdata= amelia.valid1[,-1], type="response"))
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)


#################### make some predictions for submission ##############
test=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)
test=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)

for(i in 1:nrow(test)){
  if (test[i,3] > 1){
    test[i,3]= 1
  }}

test[,3]=logit(test[,3]^.5)
for(i in 1:nrow(test)){
  if (test[i,5]>13){
    test[i,5]=13
  }
}



amelia.test=amelia(test[,-(1:2)])
amelia.test1=amelia.test$imputations$imp1
amelia.test1$NumberOfDependents=round(amelia.test1$NumberOfDependents)
amelia.test1$MonthlyIncome=round(amelia.test1$MonthlyIncome)
amelia.test1=abs(amelia.test1)


pred=predict(amelia.glm, newdata= amelia.test1, type="response")
pred=as.data.frame(pred)
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"glm_submission3 triple interactions.csv",row.names = FALSE)





############load data and put in correct format##############

train=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-training.csv", header=TRUE)
train=train[,-1]
sample.list=sample(nrow(train), nrow(train)/10)

train.set=train[-sample.list,]
valid.set=train[sample.list,]
amelia.set=amelia(train.set)

amelia.set1=amelia.set$imputations$imp1
amelia.set1$NumberOfDependents=round(amelia.set1$NumberOfDependents)
amelia.set1$MonthlyIncome=round(amelia.set1$MonthlyIncome)
amelia.set1=abs(amelia.set1)
amelia.set1$SeriousDlqin2yrs=as.factor(amelia.set1$SeriousDlqin2yrs)


############ fit a model###############
amelia.glm.full=glm(SeriousDlqin2yrs~ .*., data=amelia.set1, family="binomial")
amelia.glm.null=glm(SeriousDlqin2yrs~+1, data=amelia.set1,family="binomial")


###used this to get the model###

#step(amelia.glm.null, direction="both", scope=list(lower=amelia.glm.null, upper=amelia.glm.full),
#     scale=0)

####################

amelia.glm=glm(formula = SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans, 
               family = "binomial", data = amelia.set1)
summary(amelia.glm)
spreadLevelPlot(amelia.glm)
plot(exp(residuals(amelia.glm)))
qqPlot(exp(residuals(amelia.glm)))
hist(exp(abs(residuals(amelia.glm))), breaks=100)

############ put valid set data in right format
amelia.valid=amelia(valid.set)
amelia.valid1=amelia.valid$imputations$imp1
amelia.valid1$NumberOfDependents=round(amelia.valid1$NumberOfDependents)
amelia.valid1$MonthlyIncome=round(amelia.valid1$MonthlyIncome)
amelia.valid1=abs(amelia.valid1)
amelia.valid1$SeriousDlqin2yrs=as.factor(amelia.valid1$SeriousDlqin2yrs)


#################### make some predictions ##############
pred=round(predict(amelia.glm, newdata= amelia.valid1[,-1], type="response"))
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)


#################### make some predictions for submission ##############
test=read.csv(file="C:/Users/lvckr/OneDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)
test=read.csv(file="C:/Users/Nathan/SkyDrive/Documents/School/Machine Learning/Final Project/cs-test.csv", header=TRUE)
amelia.test=amelia(test[,-(1:2)])
amelia.test1=amelia.test$imputations$imp1
amelia.test1$NumberOfDependents=round(amelia.test1$NumberOfDependents)
amelia.test1$MonthlyIncome=round(amelia.test1$MonthlyIncome)
amelia.test1=abs(amelia.test1)


pred=predict(amelia.glm, newdata= amelia.test1, type="response")
pred=as.data.frame(pred)
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"glm_submission3.csv",row.names = FALSE)

#################################################################
############ fit a model###############
amelia.glm.full=glm(SeriousDlqin2yrs~ .*., data=amelia.set1, family="binomial")
amelia.glm.null=glm(SeriousDlqin2yrs~+1, data=amelia.set1,family="binomial")


###used this to get the model###

#step(amelia.glm.null, direction="both", scope=list(lower=amelia.glm.null, upper=amelia.glm.full),
#     scale=0)

####################

amelia.glm=glm(formula = SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans + MonthlyIncome:NumberRealEstateLoansOrLines, 
               family = "binomial", data = amelia.set1)
summary(amelia.glm)




#################### make some predictions ##############
pred=round(predict(amelia.glm, newdata= amelia.valid1[,-1], type="response"))
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)


#################### make some predictions for submission ##############


pred=predict(amelia.glm, newdata= amelia.test1, type="response")
pred=as.data.frame(pred)
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"glm_submission2.csv",row.names = FALSE)



#####################################################

####################fit a model and  make some predictions ##############
knn.pred=knn(amelia.set1[-1], amelia.valid1[,-1], amelia.set1[,1],k=3)
summary(knn.pred)


sum(amelia.valid1[,1]==knn.pred)
mean(amelia.valid1[,1]==knn.pred)
table(amelia.valid1[,1],knn.pred)

library(Amelia)
library(car)

############ fit a model###############
amelia.lda=lda(SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans, data = amelia.set1)
summary(amelia.lda)




#################### make some predictions ##############
pred=predict(amelia.lda, newdata= amelia.valid1[,-1])
pred.class=pred$class
sum(valid.set[,1]==pred.class)
mean(valid.set[,1]==pred.class)
table(valid.set[,1],pred.class)

#################### make some predictions for submission ##############

pred=predict(amelia.lda, newdata= amelia.test1)
pred=as.data.frame(pred$posterior[,2])
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"lda_submission with transformations triple interactions.csv",row.names = FALSE)

######################################################################



amelia.qda=qda(SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans + 
                 MonthlyIncome:NumberRealEstateLoansOrLines, data = amelia.set1)
summary(amelia.qda)



#################### make some predictions ##############
pred=predict(amelia.qda, newdata= amelia.valid1[,-1])
pred.class=pred$class
sum(valid.set[,1]==pred.class)
mean(valid.set[,1]==pred.class)
table(valid.set[,1],pred.class)

#################### make some predictions for submission ##############


pred=predict(amelia.qda, newdata= amelia.test1)
pred=as.data.frame(pred$posterior[,2])
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"qda_submission.csv",row.names = FALSE)

#######################################################################


############ fit a model###############

amelia.rf=randomForest(SeriousDlqin2yrs~., data=amelia.set1, do.trace=TRUE, mtry=125, nodesize=100)
summary(amelia.rf)



#################### make some predictions ##############
pred=predict(amelia.rf, newdata= amelia.valid1[,-1], type="response")

sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)


###############predict on the test set ##########

pred=predict(amelia.rf, newdata= amelia.test1, type="prob")
pred=as.data.frame(pred[,2])
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"rf submission.csv",row.names = FALSE)

#############################################################



############ fit a model###############
grid=10^seq(10,-2,length=100)

amelia.ridge=glmnet(x=as.matrix(amelia.set1[,-1]),y=as.matrix(amelia.set1[,1]), 
                    alpha=0, lambda=grid, family="binomial")
summary(amelia.ridge)




#################### make some predictions ##############
pred=predict(amelia.ridge, s=0,newx= as.matrix(amelia.valid1[,-1]), type="response")
pred=exp(pred)
pred=round(pred)
sum(valid.set[,1]==pred)
mean(valid.set[,1]==pred)
table(valid.set[,1],pred)



############ fit a model###############
amelia.lda=lda(SeriousDlqin2yrs ~ age + NumberOfTime30.59DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse + NumberOfTimes90DaysLate + 
                 MonthlyIncome + NumberRealEstateLoansOrLines + NumberOfDependents + 
                 NumberOfOpenCreditLinesAndLoans + NumberOfTime30.59DaysPastDueNotWorse:NumberOfTime60.89DaysPastDueNotWorse + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTimes90DaysLate + age:MonthlyIncome + MonthlyIncome:NumberOfDependents + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfTimes90DaysLate + 
                 age:NumberOfTime60.89DaysPastDueNotWorse + age:NumberOfDependents + 
                 NumberOfTimes90DaysLate:NumberOfOpenCreditLinesAndLoans + 
                 NumberRealEstateLoansOrLines:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime30.59DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 NumberOfTime60.89DaysPastDueNotWorse:NumberOfOpenCreditLinesAndLoans + 
                 age:NumberOfOpenCreditLinesAndLoans, data = amelia.set1)
summary(amelia.lda)




#################### make some predictions ##############
pred=predict(amelia.lda, newdata= amelia.valid1[,-1])
pred.class=pred$class
sum(valid.set[,1]==pred.class)
mean(valid.set[,1]==pred.class)
table(valid.set[,1],pred.class)

#################### make some predictions for submission ##############


pred=predict(amelia.lda, newdata= amelia.test1)
pred=as.data.frame(pred$posterior[,2])
Id <- as.integer(seq(1,101503))
predictions <- as.data.frame(cbind(Id, pred))
names(predictions)[1] <- "Id"
names(predictions)[2] <- "Probability"
#names(pred)[1] <- "Probability"

write.csv(predictions,"lda_submission1.csv",row.names = FALSE)


#############################
train.h2o=as.h2o(amelia.set1, "train.h2o")

valid.h2o=as.h2o(amelia.valid1, "test.h2o")


############ fit a model###############
hidden <- c(28, 28, 28)

amelia.h2o <- h2o.deeplearning(x = 2:11, y = 1, 
                               ##standardize = FALSE,
                               training_frame = train.h2o,
                               ignore_const_cols = FALSE,
                               hidden = hidden,
                               epochs = 500,
                               rate=.5,
                               ##balance_classes=TRUE,
                               loss="CrossEntropy",
                               distribution = "bernoulli",
                               activation="RectifierWithDropout",
                               fast_mode = TRUE)




#################### make some predictions ##############
yhat <- h2o.predict(amelia.h2o, valid.h2o)
ImageId <- as.numeric(seq(1,15000))
names(ImageId)[1] <- "ImageId"
predictions <- cbind(as.data.frame(ImageId),as.data.frame(as.numeric(yhat[,1])))
names(predictions)[2] <- "Label"

mean(predictions$Label == valid.set[,1]) 
table(predictions$Label, valid.set[,1])


##############  load the test data and get in right format##########
test.h2o=as.h2o(amelia.test1, "test.h2o")



#################### make some predictions on test set to submit ##############
yhat <- h2o.predict(amelia.h2o, test.h2o)
probs=as.data.frame(yhat)
prob0=probs$p0
prob0
prob0=as.numeric(prob0)
prob0
